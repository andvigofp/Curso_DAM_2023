public class Rela2Ejer9 {
    public static void main(String[] args) {

    /*
    Crea las variables nombre, dirección y teléfono y asígnales los valores
     correspondientes. Muestra los valores de esas variables por pantalla.
    */
     String nombre= "antonio perez gonzález";
     String direccion= "calle oliva 22";
     String telefono = "987-99-99-99";
     System.out.println("nombre = " + nombre);
     System.out.println("direccion = " + direccion);
     System.out.println("telefono = " + telefono);

    }
}
