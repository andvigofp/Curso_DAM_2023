import java.util.Scanner;

public class EjerNotasIf {
    public static void main(String[] args) {
    /* Se trata de insertar notas y que muestre si la nota insertada está en el rango de suficiente/bien/nota/sobre
    Se ha realizado con if y en el segundo bloque se realiza con switch case
     */

        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce una nota por teclado ");

        int nota = sc.nextInt();
        if (nota < 5 && nota >= 0) {
            System.out.println("Insuficiente");
        } else if (nota == 5) {
            System.out.println("Suficiente");

        } else if (nota == 6) {
            System.out.println("Bien");

        } else if (nota == 7 || nota == 8) {
            System.out.println("notable");

        } else if (nota == 9 || nota == 10) {

            System.out.println("Sobresaliente");
        }
     


        System.out.println("Introduzca una nota");
        int nota1 = sc.nextInt();
        switch (nota1){

            case 0,1,2,3,4 -> System.out.println("Insuficiente");
            case 5 -> System.out.println("Suficiente");
            case 6 -> System.out.println("Bien");
            case 7,8 -> System.out.println("notable");
            case 9,10 -> System.out.println("sobresaliente");
            default -> System.out.println("No es una nota adecuada");
        }

    }
}


