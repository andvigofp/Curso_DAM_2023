public class Rela2Ejer8 {
    public static void main(String[] args) {

         /*
        Crea la variable nombre y asígnale tu nombre completo. Muestra su valor por
        pantalla
         */
        String nombre ="Antonio González Pérez";
        System.out.println(nombre.toUpperCase());
    }
}
