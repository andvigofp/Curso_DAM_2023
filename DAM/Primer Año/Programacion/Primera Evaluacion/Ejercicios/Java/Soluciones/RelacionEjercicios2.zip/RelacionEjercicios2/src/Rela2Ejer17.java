import java.util.Scanner;

public class Rela2Ejer17 {
    public static void main(String[] args) {

        /*
        Escribe un programa que calcule el salario semanal de un empleado en base a las
    horas trabajadas, a razón de 12 euros la hora
         */
        final int PRECIOHORA=12;
        double horaTrabajada,sueldo;

        Scanner sc = new Scanner(System.in);
        System.out.println("Cuántas horas has trabajado ?");
        horaTrabajada = sc.nextInt();
        sueldo = PRECIOHORA*horaTrabajada;
        System.out.println("El sueldo en función de las " +(int)horaTrabajada+ " horas trabajadas a razón de :"+PRECIOHORA+"€ la hora son : "+sueldo+" Euros");

    }
}
