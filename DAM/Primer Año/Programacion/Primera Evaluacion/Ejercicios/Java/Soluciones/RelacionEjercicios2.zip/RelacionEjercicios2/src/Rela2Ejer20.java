import java.util.Scanner;

public class Rela2Ejer20 {
    public static void main(String[] args) {

        /*
        Realiza un conversor de kb  Mb
         */
        double kiloBytes;
        String rojo ="\033[31m";
        Scanner sc=new Scanner(System.in);
        System.out.println ("Por favor, introduzca el número de Kb");
        kiloBytes = sc.nextDouble();
        System.out.println("Mb son "+ (kiloBytes/1024)+ rojo+" Kb");

    }
}
