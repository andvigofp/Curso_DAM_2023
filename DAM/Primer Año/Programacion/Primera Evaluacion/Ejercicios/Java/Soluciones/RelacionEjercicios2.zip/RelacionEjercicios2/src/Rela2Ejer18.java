import java.util.Scanner;

public class Rela2Ejer18 {
    public static void main(String[] args) {

        /*
        Escribe un programa que calcule el volumen de un cono según la fórmula.
        V =1/3π r2h
        */
        double altura,radio,volumen;
        double PI=Math.PI;

        Scanner sc = new Scanner(System.in);
        System.out.println("Calcular el volumen del cono");
        System.out.println("Introduce la altura del cono");
        altura = sc.nextDouble();
        System.out.println("Introduce la el radio del cono");
        radio = sc.nextDouble();
        volumen = (1.0/3.0)*PI*radio*radio*altura;
        System.out.println("El volumen del cono con altura "+altura+" y con radio "+radio+" es igual a : "+volumen);

    }
}
