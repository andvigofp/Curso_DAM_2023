public class Rela2Ejer4 {
    public static void main(String[] args) {

        System.out.println("Lunes\tMartes\tMiérc.\tJueves.\tViernes");
        System.out.println("======\t=======\t======\t=======\t=======");
        System.out.println("PROG\tPROG\tPROG\tPROG \tSIN");
        System.out.println("PROG\tPROG\tPROG\tPROG\tSIN");
        System.out.println("ED\tSIN\tSIN\tLM\tBDATO");
        System.out.println("FOL\tSIN\tSIN\tLM\tBDATO");
        System.out.println("FOL\tBDATO\tED\tBDATO\tED");
        System.out.println("FOL\tBDATO\tED\tBDATO\tED");

    }
}
