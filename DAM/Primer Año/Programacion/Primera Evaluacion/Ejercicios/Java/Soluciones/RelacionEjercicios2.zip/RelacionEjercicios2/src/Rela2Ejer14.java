public class Rela2Ejer14 {
    public static void main(String[] args) {
    /*
    Escribe un programa que calcule el total de una factura a partir de la base
    imponible (precio sin IVA). La base imponible estará almacenada en una variable.
     */
        double baseImponible = 22.75;
        System.out.printf("baseImponible = %8.2f\n", baseImponible);
        System.out.printf("IVA             %8.2f\n",(baseImponible*0.21));
        System.out.printf("Total           %8.2f\n", (baseImponible*1.21));
    }
}
