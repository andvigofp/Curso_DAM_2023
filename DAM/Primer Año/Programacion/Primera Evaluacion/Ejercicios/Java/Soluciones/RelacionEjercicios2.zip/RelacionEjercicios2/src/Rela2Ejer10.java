public class Rela2Ejer10 {
    public static void main(String[] args) {

        /*
        Realiza un conversor de pesetas a euros. La cantidad en pesetas que se quiere
        convertir deberá estar almacenada en una variable.*/

        int pesetas = 10000;
        double euros = pesetas / 166.386;
        // para mostrar dos decimales se puede usar "printf" en lugar de print o println//
        System.out.println(pesetas+ "pesetas son " + euros+ "euros");
        System.out.printf("%d pesetas son %.2f euros \n",pesetas,euros);
    }
}
