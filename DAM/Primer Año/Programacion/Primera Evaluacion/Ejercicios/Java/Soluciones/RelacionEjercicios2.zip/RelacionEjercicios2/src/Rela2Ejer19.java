import java.util.Scanner;

public class Rela2Ejer19 {
    public static void main(String[] args) {

        /*
        Realiza un conversor de Mb a Kb
         */
        double megas;
        String rojo ="\033[31m";
        Scanner sc=new Scanner(System.in);
        System.out.println ("Por favor, introduzca el número de Mb");
        megas = sc.nextDouble();
        System.out.println("Mb son "+ (int)(megas*1024)+ rojo+" Kb");

    }
}
