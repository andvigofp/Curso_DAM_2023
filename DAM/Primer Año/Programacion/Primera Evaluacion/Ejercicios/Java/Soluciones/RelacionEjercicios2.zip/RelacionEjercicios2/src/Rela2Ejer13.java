public class Rela2Ejer13 {
    public static void main(String[] args) {

        /*
        Realiza un conversor de euros a pesetas. La cantidad en euros que se quiere
        convertir deberá estar almacenada en una variable.

         */
     double euros = 6.00;
     int pesetas = (int)(euros *166.386);
     System.out.println(euros+" euros son" + pesetas+" pesetas");

    }
}
