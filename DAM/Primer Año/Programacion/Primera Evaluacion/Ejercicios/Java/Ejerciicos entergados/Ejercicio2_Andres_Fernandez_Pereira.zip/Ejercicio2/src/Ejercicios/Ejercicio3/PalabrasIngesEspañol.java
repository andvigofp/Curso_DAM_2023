package Ejercicios.Ejercicio3;

public class PalabrasIngesEspañol {
    public static void main(String[] args) {
        /**
         * Escribe un programa que muestre por pantalla 10 palabras en inglés junto a su
         * correspondiente traducción al castellano. Las palabras deben estar distribuidas en
         * dos columnas y alineadas a la izquierda.
         */
        //Sentencias de escape colores \033[32m \t (Tabulador)
        //Imprime por pantalla
        System.out.println("\033[32mIngles\033[0m\t \t\033[33mEspañol\033[0m\n");
        System.out.println("Computer\t ordenador\n");
        System.out.println("Student\t \talumo/a\n");
        System.out.println("Cat\t\t  \tgato\n");
        System.out.println("Penguin\t \tpingüino.\n");
        System.out.println("Machine\t \tmáquina\n");
        System.out.println("Nature\t \tnaturaleza\n");
        System.out.println("Light\t \tluz\n");
        System.out.println("Gree\t \tverde\n");
        System.out.println("Book\t \tLibro\n");
        System.out.println("Pyramid\t \tpirámide");

    }
}
