package Ejercicios.Ejercicio7;

public class NombreCompleto {
    public static void main(String[] args) {
        /**
         * Crea la variable nombre y asígnale tu nombre completo. Muestra su valor por
         * pantalla.
         */
        //Variable tipo carácter tipo String
        String nombre = "Andrés Fernández Pereira";

        // Mostrar el valor de la variable por pantalla
        System.out.println("Mi nombre es: " + nombre);
    }
}

