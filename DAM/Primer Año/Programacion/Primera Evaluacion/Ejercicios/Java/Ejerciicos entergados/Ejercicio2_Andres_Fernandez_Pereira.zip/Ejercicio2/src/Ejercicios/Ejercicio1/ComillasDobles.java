package Ejercicios.Ejercicio1;

public class ComillasDobles {
    public static void main(String[] args) {
        /**
         * Escribe un programa que muestre tu nombre por pantalla entre comillas dobles
         * dentro de una frase
         * Por ejemplo:
         * Soy “Antonio” y estoy aprendiendo Java en un entorno amigable.
         */
        //Sentencias de escape
        //Comillas Dobles "\
        System.out.println("Soy \"Antonio\" y estoy aprendiendo Java en un entorno amigable\n");
        //Bara inclinada \\
        System.out.println("E:\\Andres\\DAM\\Programacion\\Ejercicios\\Tema1\\Ejercicio2");
    }
}
