package Ejercicios.Ejercicio2;

public class ModificaDireccionTelefono {
    public static void main(String[] args) {
        /**
         * Modifica el programa anterior para que además se muestre tu dirección y tu
         * número de teléfono. Asegúrate de que los datos se muestran en líneas separadas.
         */
        //Comillas Dobles "\
        //t (Tabulador)
        System.out.println("Soy \"Antonio\" y estoy aprendiendo Java en un entorno amigable, \tTelefono: 987323223 \tDireccion: Angel De Lema Y Marina Nº15, 10C\n");

        //Bara inclinada \\
        System.out.println("E:\\Andres\\DAM\\Programacion\\Ejercicios\\Tema1\\Ejercicio2");
    }
}
