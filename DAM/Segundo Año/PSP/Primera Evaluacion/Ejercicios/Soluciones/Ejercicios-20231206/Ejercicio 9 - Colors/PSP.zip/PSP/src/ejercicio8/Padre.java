package ejercicio8;

import java.io.*;
import java.util.Scanner;

public class Padre {
    public static void main(String[] args) throws IOException, InterruptedException {
        BufferedWriter bw= new BufferedWriter(new FileWriter("./errors.txt"));
        PrintWriter pw = new PrintWriter("./errors.txt");
        ProcessBuilder pb=new ProcessBuilder("java","ejercicio8.Escritor");
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p=pb.start();
        System.out.println("El proceso Writer ha finalizado: " + p.waitFor());

        ProcessBuilder pb2=new ProcessBuilder("java","ejercicio8.Vigilante");
        pb2.directory(new File(".\\out\\production\\PSP"));
        Process p2=pb2.start();
        System.out.println("El proceso Reader ha finalizado: " + p2.waitFor());

        BufferedReader br=new BufferedReader(new InputStreamReader(p2.getInputStream()));
        String linea;
        int contador=0;
            while ((linea=br.readLine())!=null){
                contador++;
            }
        System.out.println(contador);
        pw.println("Se ha detectado " + contador + " problemas");
        pw.close();
        bw.close();
        br.close();
    }
}
