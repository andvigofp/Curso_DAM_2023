package ejercicio2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Sumar {
    public static void main(String[] args) throws IOException {
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Escibe el primer numero");
        int num1=Integer.parseInt(br.readLine());
        System.out.println("Escibe el segundo numero");
        int num2=Integer.parseInt(br.readLine());
        System.out.println("La suma es: "+(num1+num2));
    }





}
