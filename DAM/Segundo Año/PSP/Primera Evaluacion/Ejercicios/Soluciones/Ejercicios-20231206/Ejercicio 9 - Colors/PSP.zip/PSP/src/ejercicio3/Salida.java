package ejercicio3;

public class Salida {
    public static void main(String[] args) {
        if(args.length<1) System.exit(1);
        else if(Integer.parseInt(args[0])<0)System.exit(3);
        else if (Integer.parseInt(args[0])>=0) System.exit(0);
        else System.exit(2);
    }
}
