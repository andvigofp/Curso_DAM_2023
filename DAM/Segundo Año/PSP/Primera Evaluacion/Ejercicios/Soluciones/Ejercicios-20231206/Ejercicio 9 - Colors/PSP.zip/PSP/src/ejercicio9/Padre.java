package ejercicio9;

import java.io.*;
import java.util.Scanner;

public class Padre {

    public static void main(String[] args) throws IOException {
        String []colorin={"Negro","Azul","Cyan","Verde","Gris","Magenta","Naranja","Amarillo","Rojo","Violeta"};
        Scanner sc= new Scanner(System.in);
        ProcessBuilder pb=new ProcessBuilder("java","ejercicio9.Hijo");
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p=pb.start();
        BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));
        PrintStream ps=new PrintStream(p.getOutputStream());
        String linea;

        while ((linea=br.readLine())!=null){
            if (linea.contains("Felicidades")) {
                System.out.println(linea);
                System.exit(0);
            }
            System.out.println(linea);
            for (String color:colorin) System.out.println(color);
            System.out.println("Escribe color");
            ps.println(sc.nextLine());
            ps.flush();
        }
    }
}
