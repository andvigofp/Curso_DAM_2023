package repaso1;

public class Hijo {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("La salida es 1");
            System.exit(1);
        }
        int numero=0;
        try{
            numero=Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            System.out.println("La salida es 2");
            System.exit(2);
        }
        if (numero<1){
            System.out.println("La salida es 3");
            System.exit(3);
        }
        else if (numero>=0){
            System.out.println("La salida es 0");
            System.exit(0);
        }
        else {
            System.out.println("La salida es 2");
            System.exit(2);
        }
    }
}
