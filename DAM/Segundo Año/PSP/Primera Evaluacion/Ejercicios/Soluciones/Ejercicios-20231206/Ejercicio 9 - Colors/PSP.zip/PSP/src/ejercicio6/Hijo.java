package ejercicio6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Hijo {
    public static void main(String[] args) throws IOException {
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        String linea;
        System.out.println("Introduce cadena a mostrar");
        while((linea=br.readLine())!=null) {
            if (!linea.equals("*")) System.out.println(linea);
            else {
                System.out.println("*");
                System.exit(0);
            }
        }
    }
}
