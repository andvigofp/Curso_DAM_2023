package repaso;

import java.io.*;


public class Contador {
    public static void main(String[] args) throws IOException {
        BufferedReader br= new BufferedReader(new FileReader("./Aleatorios.txt"));
        String linea;
        int contador=0;
        while((linea=br.readLine())!=null){
            if(Integer.parseInt(linea)<50)contador++;
        }
        if (contador!=0)System.out.println(contador);
        else System.out.println("NO ha leido");
    }
}
