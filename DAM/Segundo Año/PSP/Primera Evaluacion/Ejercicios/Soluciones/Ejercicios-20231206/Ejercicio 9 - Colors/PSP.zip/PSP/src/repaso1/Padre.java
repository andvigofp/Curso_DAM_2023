package repaso1;

import java.io.*;

public class Padre {
    public static void main(String[] args) throws IOException, InterruptedException {
        File f= new File("salida_de_repaso1.txt");
        f.createNewFile();
        String algo="algo";
        ejecutarProcesohijo(algo,f);
        algo="-1";
        ejecutarProcesohijo(algo,f);
        algo="5";
        ejecutarProcesohijo(algo,f);

        ejecutarProcesohijo(f);

    }

    private static void ejecutarProcesohijo(String algo, File f) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder("java", "repaso1.Hijo", algo);
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p = pb.start();
        FileWriter fw= new FileWriter(f,true);
        BufferedReader br= new BufferedReader(new InputStreamReader(p.getInputStream()));
        String salida=String.valueOf(p.waitFor())+"\n";
        String linea;
        while((linea=br.readLine())!=null){
            fw.write(linea+"\n");
            fw.write(salida);
        }

        fw.close();
    }

    private static void ejecutarProcesohijo( File f) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder("java", "repaso1.Hijo");
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p = pb.start();
        FileWriter fw= new FileWriter(f,true);
        String salida=String.valueOf(p.waitFor())+"\n";
        BufferedReader br= new BufferedReader(new InputStreamReader(p.getInputStream()));
        String linea;
        while((linea=br.readLine())!=null){
            fw.write(linea+"\n");
            fw.write(salida);
        }
        fw.close();
    }

}
