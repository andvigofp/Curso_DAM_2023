package ejercicio7;

import java.io.*;
import java.util.Scanner;

/*
* Realiza un programa Java que lea una cadena desde la entrada estándar y visualice en
pantalla si la cadena es o no palíndromo o si la cadena está vacía (longitud = 0) Realiza
un segundo programa Java que ejecute el anterior, debe leer la cadena desde teclado y
mostrar la salida por pantalla.*/
public class Padre {
    public static void main(String[] args) throws IOException {
        Scanner sc=new Scanner(System.in);
        ProcessBuilder pb=new ProcessBuilder("java","ejercicio7.Hijo");
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p=pb.start();
        BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));
        PrintStream ps=new PrintStream(p.getOutputStream());
        String linea;
        while((linea=br.readLine())!=null) {
            System.out.println(linea);
            ps.println(sc.nextLine());
            ps.flush();

        }
    }
}
