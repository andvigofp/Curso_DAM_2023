package hilos;

public class Hilo extends Thread{
    private int variable=0;
    public void run(){

        while(true) {
            variable++;
            if (!Main.hilo1()) break;
            try {
                sleep(2000);
            } catch (InterruptedException e) {
                System.out.println("Hilo interrumpido");
            }
        }
    }
    public int variable() {
        return variable;
    }
}
