package ejercicio4;

import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws InterruptedException, IOException {
        Scanner sc=new Scanner(System.in);
        System.out.println("Introduce cadena a mostrar");
        String cadena=sc.nextLine();
        ProcessBuilder pb=new ProcessBuilder("java","ejercicio4.Cardena",cadena);
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p=pb.start();
        BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));
        String linea;
        while((linea=br.readLine())!=null) {
            System.out.println(linea);
        }
        System.out.println(p.waitFor());
    }
}
