package ejercicio7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
* Realiza un programa Java que lea una cadena desde la entrada estándar y visualice en
pantalla si la cadena es o no palíndromo o si la cadena está vacía (longitud = 0) Realiza
un segundo programa Java que ejecute el anterior, debe leer la cadena desde teclado y
mostrar la salida por pantalla.*/
public class Hijo {
    public static void main(String[] args) throws IOException {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        String linea;
        boolean palindromo=true;
        System.out.println("Palabra a evaluar por favor");
        while((linea=br.readLine())!=null){
            for (int i =0;i<(linea.length()-1)/2;i++){
                if(!linea.substring(i,i+1).equals(linea.substring(linea.length()-i-1,linea.length()-i))){
                    palindromo=false;
                    i=linea.length();
                }else palindromo=true;
            }
            System.out.println(palindromo);
        }

    }
}
