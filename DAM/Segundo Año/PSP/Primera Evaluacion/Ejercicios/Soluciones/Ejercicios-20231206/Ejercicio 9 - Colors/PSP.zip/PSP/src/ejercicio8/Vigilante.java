package ejercicio8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import static java.lang.Thread.sleep;

public class Vigilante {
    public static void main(String[] args) throws IOException, InterruptedException {
        BufferedReader br= new BufferedReader(new FileReader("./log.txt"));
        String linea;

        while((linea=br.readLine())!=null){
            if(linea.equals("ERROR")) System.out.println(linea);
            sleep(500);
        }

    }
}
