package repaso;

import java.io.*;
import java.util.Scanner;

public class Padre {
    public static void main(String[] args) throws IOException {
        Scanner sc =new Scanner(System.in);
        ProcessBuilder pb=new ProcessBuilder("java","repaso.Aleatorio");
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p=pb.start();
        PrintStream ps=new PrintStream(p.getOutputStream());
        System.out.println("Cuantos numeros quiere escribir");
        ps.println(sc.nextLine());
        ps.flush();
        ProcessBuilder p2 =new ProcessBuilder("java","repaso.Contador");
        p2.directory(new File(".\\out\\production\\PSP"));
        Process pr2 =p2.start();
        BufferedReader br=new BufferedReader(new InputStreamReader(pr2.getInputStream()));
        String linea;

        while ((linea=br.readLine())!=null){
            System.out.println(linea);
        }
    }
}
