package ejercicio2;

import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc=new Scanner(System.in);
        ProcessBuilder pb= new ProcessBuilder("java","ejercicio2.Sumar");
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p= pb.start();
        PrintStream ps=new PrintStream(p.getOutputStream());

        BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while((line=br.readLine())!=null){
            System.out.println(line);
            if(!line.contains("La suma")) {
                ps.println(sc.nextInt());
                ps.flush();
            }

        }
    }
}
