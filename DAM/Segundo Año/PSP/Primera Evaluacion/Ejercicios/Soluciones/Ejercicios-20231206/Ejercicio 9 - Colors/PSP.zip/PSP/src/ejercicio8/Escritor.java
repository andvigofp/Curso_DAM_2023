package ejercicio8;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import static java.lang.Thread.sleep;

public class Escritor {
    public static void main(String[] args) throws IOException, InterruptedException {
        StringBuilder escrituraF=new StringBuilder();
        String escritura="";
        while(!escritura.equals("END")) {
            double aleatorio= Math.random();
            if (aleatorio < 0.1) escritura = "END";
            else if (aleatorio < 0.4) escritura = "ERROR";
            else escritura = "OK";
            escrituraF.append(escritura);
            escrituraF.append("\n");
            sleep(500);
        }
        escribirFichero(String.valueOf(escrituraF));

    }

    private static void escribirFichero(String escritura) {
        //File f= new File("./log.txt");
        //if(f.exists())f.delete();
        try(BufferedWriter bw= new BufferedWriter(new FileWriter("./log.txt"))){
            bw.write(escritura);

        }catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


}
