package repaso;

import java.io.*;

public class Aleatorio {
    public static void main(String[] args) throws IOException {
        File f= new File("./Aleatorios.txt");
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        FileWriter fw= new FileWriter(f);
        int numero=Integer.parseInt(br.readLine());
        for(int i=0;i<numero;i++){
            int aleatorio=(int)(Math.random()*100+1);
            fw.write(aleatorio+"\n");
        }
        fw.close();

    }
}
