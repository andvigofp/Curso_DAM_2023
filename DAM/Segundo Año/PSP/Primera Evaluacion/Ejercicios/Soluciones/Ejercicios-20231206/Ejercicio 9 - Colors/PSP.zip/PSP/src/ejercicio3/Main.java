package ejercicio3;

import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        String[] argumentos={"29"};
        ProcessBuilder pb=new ProcessBuilder("java","ejercicio3.Salida",argumentos[0]);
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p=pb.start();
        PrintStream ps=new PrintStream(p.getOutputStream());

        System.out.println(p.waitFor());


    }
}
