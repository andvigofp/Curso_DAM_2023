package hilos;

import static java.lang.Thread.sleep;

public class Main {
    private static boolean hilo1;
    private static boolean hilo2;

    public static boolean hilo1() {
        return hilo1;
    }

    public static boolean hilo2() {
        return hilo2;
    }

    public static void main(String[] args) {
        Hilo h=new Hilo();
        Hilo2 h2=new Hilo2();

        h.start();
        h2.start();
        int variable=-1;
        hilo1=true;
        hilo2=true;
        int variable2=-1;
        while(true){
            try {
                if(!h.isInterrupted())variable=h.variable();
                else System.out.println("H ha sido interrumpido");
                if(!h2.isInterrupted())variable2=h2.variable2();
                else System.out.println("H2 ha sido interrumpido");
                if(variable>=5)hilo1=false;
                if(variable2>185)hilo2=false;
                System.out.println(variable);
                System.out.println(variable2);
                if(!h.isAlive() && !h2.isAlive()) {
                    System.out.println("H y H2 no estan vivos");
                    System.exit(1);
                }
                sleep(2000);

            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }


    }
}
