package adivinar;

import java.io.*;
import java.util.Scanner;

public class Padre {
    public static void main(String[] args) throws IOException, InterruptedException {
        Scanner sc=new Scanner(System.in);
        ProcessBuilder pb= new ProcessBuilder("java","adivinar.Hijo");
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p= pb.start();
        PrintStream ps=new PrintStream(p.getOutputStream());

        BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));
        String linea;
        while((linea=br.readLine())!=null){
            System.out.println(linea);
            if(!linea.contains("Felicidades")){
                if(!linea.contains("El")){
                    ps.println(sc.nextInt());
                    ps.flush();
                }
            }
        }
        
    }
}
