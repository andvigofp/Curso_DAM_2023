package ejercicio5;

import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws InterruptedException, IOException {
        File f=new File("cadena.txt");
        Scanner sc=new Scanner(System.in);
        System.out.println("Introduce cadena a mostrar");
        String cadena=sc.nextLine();
        ProcessBuilder pb=new ProcessBuilder("java","ejercicio4.Cardena",cadena);
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p=pb.start();
        BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));

        BufferedWriter wr=new BufferedWriter(new FileWriter(f));
        String linea;
        while((linea=br.readLine())!=null) {
            wr.write(linea+"\n");
        }
        wr.close();
        System.out.println(p.waitFor());
        br.close();
    }
}
