public class LeerNombre {
    public static void main(String[] args) {
        if (args.length > 0) {
            for (String palabra:args) {
                System.out.print(palabra+" ");
            }
        }
        if(args != null)System.exit(1);
        else System.exit(0);
    }
}