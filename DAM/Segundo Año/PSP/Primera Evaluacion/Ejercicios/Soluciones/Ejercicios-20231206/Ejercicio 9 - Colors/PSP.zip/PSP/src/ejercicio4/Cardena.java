package ejercicio4;

public class Cardena {
    public static void main(String[] args) {
        if(args.length<1){
            System.out.println("No se han recibido argumentos");
            System.exit(1);
        }else {
            String cadena=args[0];
            for (int i=0;i<5;i++){
                System.out.println(cadena);
            }
        }
    }
}
