package hilos;

public class Hilo2 extends Thread{
    private int variable2=0;
    public void run(){

        while(true) {
            variable2+=50;
            if (!Main.hilo2())break;
            try {
                sleep(2000);
            } catch (InterruptedException e) {
                System.out.println("Hilo2 interrumpido");
            }
        }
    }

    public int variable2() {
        return variable2;
    }
}
