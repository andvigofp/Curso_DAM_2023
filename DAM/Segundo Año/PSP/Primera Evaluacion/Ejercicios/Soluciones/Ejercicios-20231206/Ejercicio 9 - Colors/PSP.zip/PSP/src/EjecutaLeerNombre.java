import java.io.File;
import java.io.IOException;
import java.io.InputStream;


public class EjecutaLeerNombre {
    public static void main(String[] args) {
        int salida;
        Process p2= null;
        InputStream is;
        String[] nombre={"Gonzalo","eres","un","mal","ejemplo"};
        File f = new File(".\\out\\production\\PSP");
        //LeerNombre.main(nombre);
        ProcessBuilder pb= new ProcessBuilder("java","LeerNombre",nombre[0],nombre[1],nombre[2],nombre[3],nombre[4]);
        pb.directory(f);
        try {
            p2 = pb.start();
            is= p2.getInputStream();
            salida=p2.waitFor();
            int c;
            StringBuilder s=new StringBuilder();
            while ((c=is.read())!=-1){
                s.append((char) c);
            }
            System.out.println(s);
        } catch (IOException | InterruptedException e) { throw new RuntimeException(e);}
        if(salida==1) System.out.println("Ejecutado correcto");
        else System.out.println("Algo ha fallado");
    }
}
