package ejercicio6;
/*
* Crea un programa Java que lea cadenas desde la entrada estándar hasta recibir un *.
A continuación, crea un programa padre que ejecute el anterior. El programa padre
deberá enviarle las cadenas al hijo y también recoger los mensajes del hijo. Gestiona
ambos programas para que al escribir “*” ambos finalicen. Asegurate desde el padre
que el hijo ha finalizado correctamente.
* */

import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        Scanner sc=new Scanner(System.in);
        ProcessBuilder pb=new ProcessBuilder("java","ejercicio6.Hijo");
        pb.directory(new File(".\\out\\production\\PSP"));
        Process p=pb.start();
        BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));
        PrintStream ps=new PrintStream(p.getOutputStream());

        String orden="";
        String linea;

            while((linea=br.readLine())!=null) {
                if(!linea.equals("*") ){
                    System.out.println(linea);
                    orden=sc.nextLine();
                    ps.println(orden);
                    ps.flush();
                } else System.out.println("deberia acabarse aqui");
            }
        System.out.println(p.waitFor());
        br.close();
        ps.close();

    }
}
