package adivinar;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Hijo {
    public static void main(String[] args) throws IOException {
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        int aleatorio= (int) Math.floor(Math.random()*100)+1;

        System.out.println("Cuantos intentos necesitas");
        int intentos=Integer.parseInt(br.readLine());

        for(int i=0;i<intentos;i++) {
            System.out.println("Intento numero "+(i+1)+" te quedan "+(intentos-i));
            int num=Integer.parseInt(br.readLine());
            if (aleatorio == num) {
                System.out.println("Felicidades has acertado el numero secreto " + aleatorio);
                System.exit(0);
            } else if (aleatorio > num) System.out.println("El numero secreto es mayor");
            else System.out.println("El numero secreto es menor");
        }
        System.out.println("Se acabo no lo has adivinado "+aleatorio+" era el numero");

    }
}
