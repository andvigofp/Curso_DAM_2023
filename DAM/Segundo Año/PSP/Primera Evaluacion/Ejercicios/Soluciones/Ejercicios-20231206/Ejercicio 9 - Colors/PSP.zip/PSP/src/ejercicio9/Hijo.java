package ejercicio9;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class Hijo {
    public static void main(String[] args) throws IOException {
        double aleatorio= Math.random();
        String []colorin={"Negro","Azul","Cyan","Verde","Gris","Magenta","Naranja","Amarillo","Rojo","Violeta"};
        String seleccion = getString(aleatorio, colorin);
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        String linea;
        System.out.println("Color o chupito?");
        while ((linea=br.readLine())!=null){
            if (linea.equals(seleccion)) {
                System.out.println("Felicidades has acertado era: "+seleccion);
                System.exit(0);
            } else System.out.println("Fallaches rapaz, chupito");
        }
    }

    private static String getString(double aleatorio, String[] colorin) {
        String seleccion;
        if (aleatorio <0.1) {
            seleccion= colorin[0] ;
        } else if (aleatorio <0.2) {
            seleccion= colorin[1] ;
        } else if (aleatorio <0.3) {
            seleccion= colorin[2] ;
        } else if (aleatorio <0.4) {
            seleccion= colorin[3] ;
        } else if (aleatorio <0.5) {
            seleccion= colorin[4] ;
        } else if (aleatorio <0.6) {
            seleccion= colorin[5] ;
        }else if (aleatorio <0.7) {
            seleccion= colorin[6] ;
        }else if (aleatorio <0.8) {
            seleccion= colorin[7] ;
        }else if (aleatorio <0.9) {
            seleccion= colorin[8] ;
        } else {
            seleccion= colorin[9] ;
        }
        return seleccion;
    }




}
