import java.io.*;
import java.util.Scanner;

public class Main {
    static File f;
    static Process p2;
    public static void main(String[] args) {
        InputStream is;
        f = new File("textoPSP.txt");
        escribir("vamos a probar");
        leer();

        ProcessBuilder pb= new ProcessBuilder("notepad.exe", f.getAbsolutePath());
        try {
            p2=pb.start();
            is=p2.getInputStream();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        int c;
        try{
            while ((c=is.read()) != -1) {
                System.out.print((char)c);
            }
        }catch (IOException e){
            throw new RuntimeException(e);
        }
        int salida;
        try{
            salida= p2.waitFor();
            System.out.println("valor de salida "+salida);
        }catch (InterruptedException e){e.printStackTrace();}
            pedirInt("Introduce entero");
        }


    private static void pedirInt(String introduceEntero) {
        System.out.println(introduceEntero);
        Scanner scn=new Scanner(System.in);
        if(scn.hasNextInt()){
            System.out.println("Ha introducido un int");
            System.exit(0);
        }
        else {
            System.out.println("No ha introducido un int");
            System.exit(-1);
        }
    }

    public static void escribir(String texto){

        try (FileWriter fw = new FileWriter(f)){
            fw.write(texto);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Texto escrito correctamente");
    }

    public static void leer(){
        StringBuilder text=new StringBuilder();
        try (FileReader fr = new FileReader(f);
             BufferedReader br = new BufferedReader(fr)) {
            String s;
            while ((s = br.readLine()) != null) {
                text.append(s);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println(text);
        System.out.println("Texto leído correctamente");
    }
}
