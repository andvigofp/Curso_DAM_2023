public class Ejercicio8Versionnueva {
    public static void main(String[] args) {
        
    }
}
