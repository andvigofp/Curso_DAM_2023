public class App {
    public static void main(String[] args) throws Exception {
        /**
         * Proceso hijo:
         * Tiene que tener declarados 10 colores y escoger uno de ellos aleatoriamente
         * cada vez que se ejecuta.
         * Recibe desde la entrada estandar eleciones de colores hasta que se acierte.
         * 
         * Proceso padre:
         * Tiene que lanzar al hijo y enviarle a través de la memoria el color que
         * eligamos.
         * El juego finaliza cuando acertamos.
         * 
         */
    }
}
